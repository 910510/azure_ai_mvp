pip install streamlit openai azure-search-documents python-dotenv

python -m streamlit run chat.py --server.port 8000 --server.address 0.0.0.0
# bash /home/site/wwwroot/run.sh